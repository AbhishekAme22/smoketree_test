// server.js
const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');

const app = express();

// parse application/json
app.use(bodyParser.json());
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/form.html');
  });
app.post('/user', (req, res) => {
  const { name, email, street, city, state, zipCode } = req.body;
  // create a connection to the database
  console.log("ok")
  const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '1234',
    database: 'smoketree'
  });

  // insert a row into the users table
  connection.query(
    'INSERT INTO users (name, email) VALUES (?, ?)',
    [name, email],
    (error, results) => {
      if (error) throw error;
      // retrieve the user_id of the inserted row
      const userId = results.insertId;
      // insert a row into the addresses table
      connection.query( 
        'INSERT INTO addresses (user_id, street, city, state, zip_code) VALUES (?, ?, ?, ?, ?)',
        [userId, street, city, state, zipCode],
        (error, results) => {
          if (error) throw error;
          res.send('User and address added to database');
        }
      );
    }
  );
});

app.listen(3000, () => {
  console.log('Server listening on port 3000');
});
