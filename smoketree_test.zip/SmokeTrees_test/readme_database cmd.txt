CREATE TABLE users (
    ->   user_id INTEGER PRIMARY KEY AUTO_INCREMENT,
    ->   name VARCHAR(255) NOT NULL,
    ->   email VARCHAR(255) NOT NULL
    -> );

 CREATE TABLE addresses (
    ->        address_id INTEGER PRIMARY KEY AUTO_INCREMENT,
    ->        user_id INTEGER NOT NULL,
    ->        street VARCHAR(255) NOT NULL,
    ->        city VARCHAR(255) NOT NULL,
    ->        state CHAR(2) NOT NULL,
    ->    zip_code CHAR(5) NOT NULL,
    ->      FOREIGN KEY (user_id) REFERENCES users (user_id)
    ->      );

